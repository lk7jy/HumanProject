

from django.shortcuts import render, get_object_or_404

from .models import Human, Profession


def index(request):
	human = Human.objects.all()
	professions = Profession.objects.all()
	context = {
	'human': human,
	'title': 'Список новостей о людях',

	}
	return render(request, 'Human/index.html', context = context)





#def test(request):
#	return HttpResponse('<h3>Test Page</h3>')


def get_profession(request, profession_id):
	human = Human.objects.filter(profession_id = profession_id)
	professions = Profession.objects.all()
	profession = Profession.objects.get(pk=profession_id)
	context = {
		'human': human,

		'profession': profession
	}
	return render(request, 'Human/profession.html' ,context=context)

def view_human(request, human_id):
	#human_item = Human.objects.get(pk = human_id)
	human_item = get_object_or_404(Human, pk = human_id)
	context = {
		'human_item': human_item
	}
	return render(request, 'human/view_human.html', context = context)