from django.db import models
from django.urls import reverse_lazy
class Human(models.Model):
	title = models.CharField(max_length = 150, verbose_name = 'Заголовок')
	content = models.TextField(blank = True, verbose_name = 'Текст')
	created_at = models.DateTimeField(auto_now_add = True, verbose_name = 'Создано')
	updated_at = models.DateTimeField(auto_now = True, verbose_name = 'Изменено')
	photo = models.ImageField(upload_to = 'media/%Y/%m/%d', verbose_name = 'Фото')
	is_published = models.BooleanField(default = True, verbose_name = 'Публикация')
	profession=models.ForeignKey('Profession', on_delete =models.PROTECT, null = True, verbose_name='Профессия') #null допускает,что категория может быть пустая

	def get_absolute_url(self):
		return reverse_lazy('view_human', kwargs = {'human_id': self.pk})

	class Meta: #подкласс для описания модели в админке
		verbose_name = 'Новость'
		verbose_name_plural = 'Новости'
		ordering = ['-created_at'] # знак минуса перед названием  сортирует не как по умолчанию(в порядке от первой созданной до последней), а мы хотим, чтобы последняя созданная была сверху,до конца чтобы они шли вниз


class Profession(models.Model):
	title = models.CharField(max_length = 150, db_index = True, verbose_name = 'Профессия')


	def get_absolute_url(self):
		return reverse_lazy('Profession', kwargs={'profession_id': self.pk})
	class Meta:
		verbose_name = 'Профессия'
		verbose_name_plural = 'Профессии'
		ordering = ['title']










