from django.contrib import admin
from .models import Human, Profession

class HumanAdmin(admin.ModelAdmin): # наследование от встроенного класса модели для страницы администратора
	list_display = ('id','profession', 'title','content','created_at',
'photo',
'is_published')
	list_display_links = ('id','title')
	search_fields = ('title','content')
	list_filter = ('is_published', 'id')
	list_editable = ('is_published','profession')


class ProfessionAdmin(admin.ModelAdmin):
	list_display = ('id', 'title')
	list_display_links = ('id','title')



admin.site.register(Human, HumanAdmin)
admin.site.register(Profession, ProfessionAdmin) #вначале пишется это, потом создаётся таблица categoryadmin
